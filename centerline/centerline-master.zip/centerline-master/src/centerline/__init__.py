# -*- coding: utf-8 -*-

from __future__ import unicode_literals


__title__ = 'centerline'
__version__ = '0.6.3'
__author__ = 'Filip Todic'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2014-present Filip Todic'

# Version synonym
VERSION = __version__
